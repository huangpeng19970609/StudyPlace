What's New in Foxit PDF Editor 2.1
======================================================================================================================

Foxit PDF Editor 2.1 has introduced some new features and enhancements that are listed below:


1. Shading Object Support
Enables users to create or edit a shading object, which has a smooth transition between colors across an area. Foxit PDF Editor offers linear and radial gradients for users to choose.

2. Converting Text of Path
Able to convert the selected text object(s) into path(s), which will meet the pre-press requirement. For those computers which do not support or display certain embedded fonts, this new feature helps to overcome that issue. Foxit PDF Editor also offers a menu option for users to convert the entire text in a PDF to path.

3. Adding Shapes in Non-Graphics Editing Mode
Provides several simple auto shapes that users can insert into a PDF in the non-graphics editing mode. With this new version, users can easily add a simple shape in the main interface of Foxit PDF Editor without having to enter into the graphics editor. 

4. Removing all evaluation marks at once
Removes all the evaluation marks on a PDF file that was added by Foxit PDF Editor 2.1 all at once by selecting "Remove Evaluation Marks" under the Help menu for registered users.

5. Alignment Support
Automatically places or aligns the selected objects evenly with the Objects Align button on the toolbar. This feature helps to make your structured PDF pages more professional.

6. Image Transparency Support
This allows users the ability to set image transparency with alpha channel. By inputting values of between 0% and 100% in Image Alpha text field, the image goes from fully transparent to fully opaque.

7. Checking for Update
This option under the Help menu detects the new version of Foxit PDF Editor and keeps you updated with the latest release.

8. Improved Text Objects Creating
Adds an Object attributes option in Add new text objects dialog box, making it easier for users to set preferences for text objects, such as font size, text mode, word space, color, etc.

9. Property List Setting
This setting determines to either show or hide the Property List when launching Foxit PDF Editor by doing settings in the Options dialog box.

10. New Shortcut Keys
Adds several new shortcut keys to make Foxit PDF Editor easier to use, i.e. ESC is shortcut for saving and exiting the in-place editing mode, Alt+Delete fills a selection with the foreground color, Ctrl+Delete fills a selection with the background color, and Ctrl+D deselects a selction.

11. New Icon
The new attractive Foxit PDF Editor icon, having a pen inside a purple box, indicates more powerful editing features have been included in the new version. 

12. Many Bug Fixes




Known Issues
===========================================================================================================================================

1. Slow response when saving certain PDF documents.
2. Form objects are not fully supported.
3. Certain PDFs cannot be opened with Adobe Acrobat after saving with Foxit PDF Editor.
4. The changes of paths cannot be saved when users click to save PDFs in Graphics Editing Mode.
5. Foxit PDF Editor may crash when loading a large existing image.
6. The images in certain PDFs become even larger after editing in Foxit PDF Editor.
7. The Unicode character set is not fully supported.
8. The toolbar goes out of place after users float all the toolbars and then double-click to dock them.




Download the Latest Version
========================================================================================================================
You can download the latest version of Foxit PDF Editor from our website at www.foxitsoftware.com.




Contact Us
========================================================================================================================
If you have any questions using Foxit PDF Editor, please feel free to contact us:

Sales and Information - sales@foxitsoftware.com
Technical Support - support@foxitsoftware.com
Website Questions - webmaster@foxitsoftware.com



Foxit Software Company
Address: 39819 Paseo Padre Parkway, Fremont, CA 94538, USA
Sales Phone: 1-866-MYFOXIT or 1-866-693-6948, 510-438-9090, 408-307-9358 
Support Phone: 1-866-MYFOXIT or 1-866-693-6948, 979-446-0280, 408-329-7976
Fax: 510-405-9288
Web: www.foxitsoftware.com