declare module '*.css';
declare module '*.scss';
declare module '*.jpg';
